package Proyecto2;

public class Cliente {
    private int id;
    private String nombre;
    private int TPagos;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getTPagos() {
        return TPagos;
    }

    public void setTPagos(int TPagos) {
        this.TPagos = TPagos;
    }
}

