package Proyecto2;

public class Individual extends Cliente {
    public String Dpi;
    public String contacto;

    public String getDpi() {
        return Dpi;
    }

    public void setDpi(String dpi) {
        Dpi = dpi;
    }

    public String getContacto() {
        return contacto;
    }

    public void setContacto(String contacto) {
        this.contacto = contacto;
    }
}
