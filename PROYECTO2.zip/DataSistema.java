package Proyecto2;

public class DataSistema {
    private String No_orden;
    private String Coorrelativo;

    public String getNo_orden() {
        return No_orden;
    }

    public void setNo_orden(String no_orden) {
        No_orden = no_orden;
    }

    public String getCoorrelativo() {
        return Coorrelativo;
    }

    public void setCoorrelativo(String coorrelativo) {
        Coorrelativo = coorrelativo;
    }
}
